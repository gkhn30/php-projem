<?php
// api_kitchen.php - YETKİLENDİRME VE SAAT AYARLI FİNAL
ob_start();
session_start();
include 'db.php';
ob_end_clean();

date_default_timezone_set('Europe/Istanbul');
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['role'])) { echo "[]"; exit; }

// Hedef Kullanıcıyı Belirle (Admin desteği)
$target_user_id = $_SESSION['user_id'];
if (($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'restaurant') && isset($_GET['target_id'])) {
    $target_user_id = $_GET['target_id'];
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    if ($action == 'get_pending') {
        $sql = "SELECT o.id, o.created_at, o.updated_at, t.table_name, o.kitchen_status, o.status
                FROM orders o
                LEFT JOIN restaurant_tables t ON o.table_id = t.id
                WHERE o.user_id = ? 
                AND o.status = 'active'
                AND (o.kitchen_status = 'pending' OR o.kitchen_status IS NULL OR o.kitchen_status = '')
                ORDER BY o.id ASC";
                
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$target_user_id]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $output = [];
        
        foreach($orders as $order) {
            $masa = !empty($order['table_name']) ? $order['table_name'] : "Masa #" . $order['id'];
            
            // Saat Düzeltme
            $db_time = !empty($order['created_at']) ? $order['created_at'] : $order['updated_at'];
            if ($db_time) {
                $dt = new DateTime($db_time);
                $dt->setTimezone(new DateTimeZone('Europe/Istanbul'));
                $saat = $dt->format('H:i');
            } else {
                $saat = date("H:i"); 
            }

            $items = $pdo->prepare("SELECT product_name, quantity FROM order_items WHERE order_id = ?");
            $items->execute([$order['id']]);
            $p_items = $items->fetchAll(PDO::FETCH_ASSOC);

            if (count($p_items) == 0) $p_items[] = ['product_name' => '⚠️ İÇERİK YOK', 'quantity' => 0];

            $output[] = [
                'id' => $order['id'],
                'table_name' => $masa,
                'formatted_time' => $saat,
                'items' => $p_items
            ];
        }
        echo json_encode($output, JSON_UNESCAPED_UNICODE);
    }
    
    elseif ($action == 'set_ready' && isset($_POST['order_id'])) {
        $pdo->prepare("UPDATE orders SET kitchen_status = 'ready' WHERE id = ?")->execute([$_POST['order_id']]);
        echo json_encode(['status'=>'success']);
    }
    elseif ($action == 'check_ready') {
        $stmt = $pdo->prepare("SELECT t.table_name, o.id FROM orders o LEFT JOIN restaurant_tables t ON o.table_id = t.id WHERE o.kitchen_status = 'ready' AND o.user_id = ?");
        $stmt->execute([$target_user_id]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC), JSON_UNESCAPED_UNICODE);
    }
    elseif ($action == 'set_served' && isset($_POST['order_id'])) {
        $pdo->prepare("UPDATE orders SET kitchen_status = 'served' WHERE id = ?")->execute([$_POST['order_id']]);
        echo json_encode(['status'=>'success']);
    }

} catch (Exception $e) {
    echo json_encode([]);
}
?>