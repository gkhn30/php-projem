<?php
session_start();
include 'db.php';

// Güvenlik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { header("Location: login.php"); exit; }

// --- FONKSİYON: KLASÖRÜ VE İÇİNDEKİLERİ SİL ---
function deleteFolder($dir) {
    if (!is_dir($dir)) return;
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        (is_dir("$dir/$file")) ? deleteFolder("$dir/$file") : unlink("$dir/$file");
    }
    return rmdir($dir);
}

// --- İŞLEMLER ---

// 1. TAM SİLME İŞLEMİ (Veritabanı + Dosyalar)
if (isset($_GET['sil_id'])) {
    $sil_id = $_GET['sil_id'];
    
    // 1. Kullanıcının klasörünü fiziksel olarak sil
    $target_dir = "uploads/" . $sil_id;
    if (file_exists($target_dir)) {
        deleteFolder($target_dir);
    }

    // 2. Veritabanından sil (CASCADE sayesinde ürünler, kategoriler, biletler de silinir)
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$sil_id]);
    
    header("Location: admin.php?msg=silindi"); exit;
}

// 2. Durum Değiştirme
if (isset($_GET['durum_id'])) {
    $yeni = ($_GET['durum'] == 1) ? 0 : 1;
    $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?")->execute([$yeni, $_GET['durum_id']]);
    header("Location: admin.php"); exit;
}

// 3. Güncelleme
if (isset($_POST['update_user'])) {
    $id = $_POST['edit_id']; $store = $_POST['edit_store_name']; $user = $_POST['edit_username']; $pass = $_POST['edit_password'];
    if (!empty($pass)) { $pdo->prepare("UPDATE users SET store_name=?, username=?, password=? WHERE id=?")->execute([$store, $user, password_hash($pass, PASSWORD_DEFAULT), $id]); } 
    else { $pdo->prepare("UPDATE users SET store_name=?, username=? WHERE id=?")->execute([$store, $user, $id]); }
    header("Location: admin.php?msg=guncellendi"); exit;
}

// İstatistikler
$total_unread = $pdo->query("SELECT COUNT(*) FROM ticket_messages WHERE sender_role = 'user' AND is_read = 0")->fetchColumn();
$users = $pdo->query("SELECT * FROM users WHERE role = 'restaurant' ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Admin Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light pb-5">

<nav class="navbar navbar-dark bg-primary mb-4 shadow">
    <div class="container">
        <span class="navbar-brand mb-0 h1"><i class="bi bi-shield-lock-fill"></i> Yönetici Paneli</span>
        <div class="d-flex align-items-center">
            <a href="admin_tickets.php" class="btn btn-light btn-sm me-3 position-relative text-primary fw-bold">
                <i class="bi bi-ticket-detailed-fill"></i> Destek Talepleri
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none" id="adminBadge">0</span>
            </a>
            <span class="text-white me-3 d-none d-md-block">Toplam: <b><?php echo count($users); ?></b></span>
            <a href="logout.php" class="btn btn-danger btn-sm">Çıkış</a>
        </div>
    </div>
</nav>

<div class="container">
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success alert-dismissible fade show">İşlem Başarılı <button class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3"><h5 class="mb-0 text-secondary">Kayıtlı İşletmeler</h5></div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light"><tr><th>ID</th><th>Restoran</th><th>Kullanıcı</th><th>Durum</th><th>Kayıt</th><th class="text-end">İşlemler</th></tr></thead>
                    <tbody>
                        <?php foreach($users as $u): ?>
                        <tr class="<?php echo ($u['is_active']==0)?'table-secondary opacity-75':''; ?>">
                            <td>#<?php echo $u['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($u['store_name']); ?></strong><br><small class="text-muted"><?php echo htmlspecialchars($u['email']); ?></small></td>
                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                            <td><a href="admin.php?durum_id=<?php echo $u['id']; ?>&durum=<?php echo $u['is_active']; ?>" class="badge text-decoration-none bg-<?php echo ($u['is_active'])?'success':'secondary'; ?>"><?php echo ($u['is_active'])?'Aktif':'Pasif'; ?></a></td>
                            <td><small><?php echo date("d.m.Y", strtotime($u['created_at'])); ?></small></td>
                            <td class="text-end">
                                <a href="panel.php?target_id=<?php echo $u['id']; ?>" target="_blank" class="btn btn-sm btn-warning" title="Yönet"><i class="bi bi-gear-fill"></i></a>
                                <a href="menu.php?id=<?php echo $u['id']; ?>" target="_blank" class="btn btn-sm btn-outline-info" title="Menü"><i class="bi bi-eye"></i></a>
                                <button class="btn btn-sm btn-outline-primary edit-btn" data-bs-toggle="modal" data-bs-target="#editModal" data-id="<?php echo $u['id']; ?>" data-store="<?php echo htmlspecialchars($u['store_name']); ?>" data-user="<?php echo htmlspecialchars($u['username']); ?>"><i class="bi bi-pencil-square"></i></button>
                                
                                <a href="admin.php?sil_id=<?php echo $u['id']; ?>" onclick="return confirm('DİKKAT! Bu işlem geri alınamaz.\n\n- Kullanıcı silinecek\n- Eklediği tüm ürünler silinecek\n- Yüklediği tüm resimler sunucudan silinecek.\n\nOnaylıyor musunuz?')" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1"><div class="modal-dialog"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Düzenle</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="edit_id" id="modal_id"><div class="mb-3"><label>Restoran Adı</label><input type="text" name="edit_store_name" id="modal_store" class="form-control" required></div><div class="mb-3"><label>Kullanıcı Adı</label><input type="text" name="edit_username" id="modal_user" class="form-control" required></div><div class="mb-3"><label>Yeni Şifre</label><input type="password" name="edit_password" class="form-control" placeholder="Değişmeyecekse boş bırakın"></div></div><div class="modal-footer"><button type="submit" name="update_user" class="btn btn-primary">Kaydet</button></div></form></div></div>

<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 9999"><div id="adminToast" class="toast" role="alert"><div class="toast-header bg-danger text-white"><strong class="me-auto">Yeni Destek Talebi</strong><button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button></div><div class="toast-body bg-white">Yeni mesaj var! <div class="mt-2 pt-2 border-top"><a href="admin_tickets.php" class="btn btn-danger btn-sm w-100">Gör</a></div></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    let lastCount = 0; const toast = new bootstrap.Toast(document.getElementById('adminToast')); const badge = document.getElementById('adminBadge');
    const editModal = document.getElementById('editModal');
    editModal.addEventListener('show.bs.modal', event => {
        const btn = event.relatedTarget;
        document.getElementById('modal_id').value = btn.getAttribute('data-id');
        document.getElementById('modal_store').value = btn.getAttribute('data-store');
        document.getElementById('modal_user').value = btn.getAttribute('data-user');
    });
    function check() {
        fetch('api_notifications.php').then(r=>r.json()).then(d=>{
            const c=parseInt(d.count);
            if(c>0){badge.innerText=c;badge.classList.remove('d-none');}else{badge.classList.add('d-none');}
            if(c>lastCount && c>0){toast.show();} lastCount=c;
        }).catch(console.error);
    }
    check(); setInterval(check, 5000);
});
</script>
</body>
</html>