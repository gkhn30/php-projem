<?php
// waiter.php - ADMİN HEDEF (TARGET_ID) DESTEKLİ
session_start();
include 'db.php';

// Güvenlik
if (!isset($_SESSION['role'])) { header("Location: login.php"); exit; }

$my_role = $_SESSION['role']; 
$waiter_id = isset($_SESSION['staff_id']) ? $_SESSION['staff_id'] : 0;

// 1. HANGİ DÜKKAN? (Admin/Sahip başkasına bakıyorsa ID değişmeli)
$user_id = $_SESSION['user_id']; // Varsayılan: Kendi dükkanım

if (($my_role == 'admin' || $my_role == 'restaurant') && isset($_GET['target_id'])) {
    $user_id = $_GET['target_id'];
    // Admin bakıyorsa, tüm masaları görmeli (sanki yetkili garsonmuş gibi)
    $waiter_id = 0; 
}

$selected_table_id = isset($_GET['table']) ? $_GET['table'] : null;

// --- SİLME İŞLEMİ ---
if (isset($_GET['del_item']) && $selected_table_id) {
    $del_id = $_GET['del_item'];
    $stmt_check = $pdo->prepare("SELECT oi.order_id, oi.price, oi.quantity, o.kitchen_status FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.id = ? AND o.user_id = ?");
    $stmt_check->execute([$del_id, $user_id]);
    $item = $stmt_check->fetch();

    if ($item) {
        $is_kitchen_started = ($item['kitchen_status'] == 'ready' || $item['kitchen_status'] == 'served');
        // Admin veya Sahip her şeyi silebilir, sadece Garson kısıtlanır
        if ($my_role == 'waiter' && $is_kitchen_started) {
            echo "<script>alert('Mutfak onayı alan ürün silinemez!'); window.location.href = 'waiter.php?table=$selected_table_id';</script>"; exit;
        }
        $deduct = $item['price'] * $item['quantity'];
        $pdo->prepare("UPDATE orders SET total_amount = total_amount - ? WHERE id = ?")->execute([$deduct, $item['order_id']]);
        $pdo->prepare("DELETE FROM order_items WHERE id = ?")->execute([$del_id]);
    }
    // Linke target_id ekleyerek geri dön
    $target_suffix = (isset($_GET['target_id'])) ? "&target_id=".$_GET['target_id'] : "";
    header("Location: waiter.php?table=" . $selected_table_id . $target_suffix); exit;
}

// Link Eki (Sayfa içi linklerde target_id kaybolmasın)
$link_suffix = (isset($_GET['target_id'])) ? "&target_id=".$_GET['target_id'] : "";
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Garson Ekranı</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; padding-bottom: 120px; }
        .table-box { height: 90px; border-radius: 12px; display: flex; flex-direction: column; justify-content: center; align-items: center; color: white; font-weight: bold; cursor: pointer; transition: transform 0.1s; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .table-box:active { transform: scale(0.95); }
        .table-empty { background: linear-gradient(135deg, #28a745, #20c997); }
        .table-occupied { background: linear-gradient(135deg, #dc3545, #f86b7d); }
        .cat-nav { overflow-x: auto; white-space: nowrap; padding: 10px 0; -webkit-overflow-scrolling: touch; scrollbar-width: none; }
        .cat-nav::-webkit-scrollbar { display: none; }
        .cat-btn { display: inline-block; padding: 8px 20px; margin-right: 8px; border-radius: 20px; background: white; color: #333; border: 1px solid #ddd; font-weight: 500; cursor: pointer; }
        .cat-btn.active { background: #0d6efd; color: white; border-color: #0d6efd; }
        .product-card { background: white; border-radius: 12px; padding: 10px; height: 100%; box-shadow: 0 2px 5px rgba(0,0,0,0.05); display: flex; flex-direction: column; justify-content: space-between; border: 1px solid #eee; transition: all 0.2s; }
        .product-card.selected { border: 2px solid #0d6efd; background-color: #f0f7ff; }
        .product-title { font-size: 0.9rem; font-weight: 700; color: #333; margin-bottom: 5px; line-height: 1.2; }
        .product-price { color: #dc3545; font-weight: bold; font-size: 1rem; }
        .qty-control { display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 10px; }
        .btn-qty { width: 35px; height: 35px; border-radius: 50%; border: none; font-weight: bold; font-size: 1.2rem; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .btn-minus { background: #e9ecef; color: #333; }
        .btn-plus { background: #0d6efd; color: white; }
        .qty-display { font-weight: bold; font-size: 1.2rem; min-width: 25px; text-align: center; }
        .cart-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; border-top: 1px solid #ccc; padding: 15px; box-shadow: 0 -4px 10px rgba(0,0,0,0.1); z-index: 1050; display: none; justify-content: space-between; align-items: center; }
        .cart-info { font-weight: bold; font-size: 1.1rem; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container-fluid">
        <?php if($selected_table_id): ?>
            <a href="waiter.php?v=1<?php echo $link_suffix; ?>" class="btn btn-outline-light btn-sm me-2"><i class="bi bi-arrow-left"></i> Masalar</a>
            <span class="navbar-brand mb-0 h1 fs-6">Masa <?php $t = $pdo->prepare("SELECT table_name FROM restaurant_tables WHERE id=?"); $t->execute([$selected_table_id]); echo htmlspecialchars($t->fetchColumn()); ?></span>
        <?php else: ?>
            <span class="navbar-brand mb-0 h1">Garson <?php if(isset($_GET['target_id'])) echo "(Admin İzleme)"; ?></span>
            <?php if(isset($_GET['target_id'])): ?>
                <a href="panel.php?target_id=<?php echo $_GET['target_id']; ?>" class="btn btn-sm btn-warning">Panele Dön</a>
            <?php else: ?>
                <a href="logout.php" class="btn btn-sm btn-danger">Çıkış</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</nav>

<div class="container-fluid py-3">
    <?php if(!$selected_table_id): ?>
        <div class="row g-3" id="tablesContainer">
            <?php
            // Masa Listeleme
            if ($my_role == 'admin' || $my_role == 'restaurant' || (isset($_GET['target_id']) && $my_role == 'admin')) {
                // Yönetici veya Admin (Target ID ile) hepsini görür
                $tables = $pdo->prepare("SELECT * FROM restaurant_tables WHERE user_id = ? ORDER BY table_name ASC");
                $tables->execute([$user_id]);
            } else {
                // Garson sadece kendi masalarını görür
                $tables = $pdo->prepare("SELECT * FROM restaurant_tables WHERE user_id = ? AND (FIND_IN_SET(?, assigned_waiter_id) OR assigned_waiter_id IS NULL OR assigned_waiter_id = '0' OR assigned_waiter_id = '') ORDER BY table_name ASC");
                $tables->execute([$user_id, $waiter_id]);
            }

            while($tbl = $tables->fetch()):
                $statusClass = ($tbl['status'] == 1) ? 'table-occupied' : 'table-empty';
            ?>
            <div class="col-4 col-md-3 col-lg-2">
                <a href="waiter.php?table=<?php echo $tbl['id'] . $link_suffix; ?>" class="text-decoration-none">
                    <div id="tbl-box-<?php echo $tbl['id']; ?>" class="table-box <?php echo $statusClass; ?>">
                        <i class="bi bi-ui-checks-grid fs-4 mb-1"></i>
                        <span><?php echo htmlspecialchars($tbl['table_name']); ?></span>
                    </div>
                </a>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <?php 
        $current_total = 0; $active_order_id = 0;
        $order_q = $pdo->prepare("SELECT id, total_amount FROM orders WHERE table_id = ? AND status = 'active'");
        $order_q->execute([$selected_table_id]);
        $active_order = $order_q->fetch();
        if($active_order) { $current_total = $active_order['total_amount']; $active_order_id = $active_order['id']; }
        ?>
        <div class="alert alert-secondary d-flex justify-content-between align-items-center py-2 px-3 mb-3">
            <span>Adisyon: <strong><?php echo number_format($current_total, 2); ?> ₺</strong></span>
            <?php if($active_order_id): ?>
                <button class="btn btn-sm btn-outline-dark" data-bs-toggle="modal" data-bs-target="#orderDetailModal">Detay</button>
            <?php endif; ?>
        </div>

        <div class="cat-nav mb-3">
            <button class="cat-btn active" onclick="filterCategory('all', this)">Tümü</button>
            <?php
            $cats = $pdo->prepare("SELECT * FROM categories WHERE user_id = ?");
            $cats->execute([$user_id]);
            $categories = $cats->fetchAll();
            foreach($categories as $c) { echo '<button class="cat-btn" onclick="filterCategory('.$c['id'].', this)">'.htmlspecialchars($c['name']).'</button>'; }
            ?>
        </div>

        <div class="row g-3 pb-5">
            <?php
            $products = $pdo->prepare("SELECT * FROM products WHERE user_id = ? AND is_active = 1");
            $products->execute([$user_id]);
            while($p = $products->fetch()):
            ?>
            <div class="col-6 col-sm-4 col-lg-3 product-item" data-cat="<?php echo $p['category_id']; ?>">
                <div class="product-card" id="card-<?php echo $p['id']; ?>">
                    <div class="text-center" onclick="changeQty(<?php echo $p['id']; ?>, 1, '<?php echo $p['name']; ?>', <?php echo $p['price']; ?>)">
                        <div class="product-title"><?php echo htmlspecialchars($p['name']); ?></div>
                        <div class="product-price"><?php echo number_format($p['price'], 2); ?> ₺</div>
                    </div>
                    <div class="qty-control" id="qty-control-<?php echo $p['id']; ?>" style="visibility: hidden;">
                        <button class="btn-qty btn-minus" onclick="changeQty(<?php echo $p['id']; ?>, -1, '<?php echo $p['name']; ?>', <?php echo $p['price']; ?>)">-</button>
                        <span class="qty-display" id="qty-<?php echo $p['id']; ?>">0</span>
                        <button class="btn-qty btn-plus" onclick="changeQty(<?php echo $p['id']; ?>, 1, '<?php echo $p['name']; ?>', <?php echo $p['price']; ?>)">+</button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <div class="cart-bar" id="cartBar">
            <div class="cart-info"><span id="cart-count">0</span> Ürün <span class="mx-2">|</span> <span id="cart-total">0.00</span> ₺</div>
            <button class="btn btn-success fw-bold px-4" onclick="submitOrder()">ONAYLA <i class="bi bi-check-circle"></i></button>
        </div>

        <div class="modal fade" id="orderDetailModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">Sipariş Detayı</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
            <?php if($active_order_id): ?>
            <ul class="list-group">
                <?php 
                $items = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?"); $items->execute([$active_order_id]);
                while($it = $items->fetch()): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div><b><?php echo $it['quantity']; ?>x</b> <?php echo htmlspecialchars($it['product_name']); ?></div>
                    <div>
                        <span class="badge bg-secondary rounded-pill me-2"><?php echo number_format($it['price']*$it['quantity'], 2); ?></span>
                        <a href="waiter.php?table=<?php echo $selected_table_id; ?>&del_item=<?php echo $it['id'].$link_suffix; ?>" class="btn btn-sm btn-danger py-0 px-2" onclick="return confirm('Silinsin mi?')">X</a>
                    </div>
                </li>
                <?php endwhile; ?>
            </ul>
            <?php else: echo "<p class='text-center text-muted'>Henüz sipariş yok.</p>"; endif; ?>
        </div></div></div></div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    <?php if(!$selected_table_id): ?>
    function updateTableStatus() {
        // API'ye target_id gönderilmeli
        const targetParam = "<?php echo isset($_GET['target_id']) ? '&target_id='.$_GET['target_id'] : ''; ?>";
        fetch('api_waiter.php?action=get_tables' + targetParam + '&t=' + Date.now())
        .then(response => response.json())
        .then(data => {
            data.forEach(table => {
                const box = document.getElementById('tbl-box-' + table.id);
                if (box) {
                    if (table.status == 1) { box.classList.remove('table-empty'); box.classList.add('table-occupied'); } 
                    else { box.classList.remove('table-occupied'); box.classList.add('table-empty'); }
                }
            });
        }).catch(err => {});
    }
    setInterval(updateTableStatus, 5000);
    <?php endif; ?>

    let cart = {}; const tableId = <?php echo $selected_table_id ? $selected_table_id : 'null'; ?>;
    function filterCategory(catId, btn) {
        document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active');
        document.querySelectorAll('.product-item').forEach(p => { p.style.display = (catId === 'all' || p.getAttribute('data-cat') == catId) ? 'block' : 'none'; });
    }
    function changeQty(pId, change, name, price) {
        if (!cart[pId]) cart[pId] = { qty: 0, price: price };
        cart[pId].qty += change; if (cart[pId].qty < 0) cart[pId].qty = 0;
        document.getElementById('qty-' + pId).innerText = cart[pId].qty;
        const cDiv = document.getElementById('qty-control-' + pId), cCard = document.getElementById('card-' + pId);
        if (cart[pId].qty > 0) { cDiv.style.visibility = 'visible'; cCard.classList.add('selected'); } else { cDiv.style.visibility = 'hidden'; cCard.classList.remove('selected'); delete cart[pId]; }
        updateCartBar();
    }
    function updateCartBar() {
        let count = 0, total = 0;
        for (let id in cart) { count += cart[id].qty; total += cart[id].qty * cart[id].price; }
        const bar = document.getElementById('cartBar');
        if (count > 0) { bar.style.display = 'flex'; document.getElementById('cart-count').innerText = count; document.getElementById('cart-total').innerText = total.toFixed(2); } else { bar.style.display = 'none'; }
    }
    function submitOrder() {
        if (!tableId) return;
        let items = []; for (let id in cart) { items.push({ id: id, qty: cart[id].qty }); }
        if (items.length === 0) return;
        const btn = document.querySelector('#cartBar button'); btn.disabled = true; btn.innerText = 'Kaydediliyor...';
        // Sipariş API'sine de target_id gönderilebilir (Session'dan aldığı için opsiyonel ama daha güvenli olabilir)
        fetch('api_order.php<?php echo $link_suffix ? "?".ltrim($link_suffix,"&") : ""; ?>', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ table_id: tableId, items: items }) })
        .then(r => r.json()).then(d => { if (d.status === 'success') location.reload(); else { alert(d.message); btn.disabled = false; btn.innerText = 'ONAYLA'; } });
    }
</script>
</body>
</html>