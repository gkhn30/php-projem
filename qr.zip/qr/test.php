<?php
// test_mutfak.php
session_start();
include 'db.php';

echo "<h1>🔍 MUTFAK SORUN TESPİTİ</h1>";

// 1. OTURUM KONTROLÜ
if (!isset($_SESSION['user_id'])) {
    die("<h3 style='color:red'>HATA: Giriş yapılmamış. Lütfen Mutfak hesabıyla giriş yapın.</h3>");
}

$my_user_id = $_SESSION['user_id'];
$my_role = $_SESSION['role'];
$my_name = $_SESSION['name'];

echo "<div style='background:#eee; padding:10px; border:1px solid #ccc;'>";
echo "<strong>Şu an Giriş Yapan:</strong> $my_name <br>";
echo "<strong>Rolü:</strong> $my_role (Olması gereken: kitchen)<br>";
echo "<strong>Sizin Restoran ID'niz (user_id):</strong> <span style='color:blue; font-size:20px'>$my_user_id</span>";
echo "</div><hr>";

// 2. SİPARİŞ KONTROLÜ
echo "<h3>📦 Veritabanındaki Aktif Siparişler</h3>";

$sql = "SELECT id, table_id, user_id, status, kitchen_status FROM orders WHERE status = 'active'";
$stmt = $pdo->query($sql);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($orders) == 0) {
    echo "<div style='background:orange; padding:10px;'>⚠ Veritabanında hiç AKTİF sipariş yok. Garson panelinden yeni bir sipariş ekleyin.</div>";
} else {
    echo "<table border='1' cellpadding='10' style='border-collapse:collapse; width:100%;'>";
    echo "<tr style='background:#ddd;'><th>Sipariş ID</th><th>Siparişin Restoran ID'si</th><th>Durum</th><th>Mutfak Durumu</th><th>SONUÇ</th></tr>";

    foreach ($orders as $o) {
        $order_user_id = $o['user_id'];
        
        // Eşleşme Kontrolü
        if ($order_user_id == $my_user_id) {
            $sonuc = "<b style='color:green'>✔ GÖRÜNMELİ</b>";
            if ($o['kitchen_status'] != 'pending') {
                $sonuc = "<b style='color:orange'>✖ GÖRÜNMEZ (Durum 'pending' değil)</b>";
            }
        } else {
            $sonuc = "<b style='color:red'>✖ GÖRÜNMEZ (ID Uyuşmuyor!)</b>";
        }

        echo "<tr>";
        echo "<td>" . $o['id'] . "</td>";
        echo "<td><span style='font-size:18px'>$order_user_id</span> " . ($order_user_id != $my_user_id ? "(Sizin ID ile aynı değil!)" : "") . "</td>";
        echo "<td>" . $o['status'] . "</td>";
        echo "<td>" . ($o['kitchen_status'] ? $o['kitchen_status'] : 'NULL (Boş)') . "</td>";
        echo "<td>$sonuc</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>