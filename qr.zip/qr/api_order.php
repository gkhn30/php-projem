<?php
// api_order.php - SAAT AYARLI VERSİYON
// Çıktı tamponlamasını temizle
ob_start();
session_start();
include 'db.php';
ob_end_clean();

// 1. SAAT AYARI (EN ÖNEMLİ KISIM)
date_default_timezone_set('Europe/Istanbul');
$simdi = date("Y-m-d H:i:s");

error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['role'])) { echo json_encode(['status'=>'error', 'message'=>'Giriş yapın']); exit; }

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];

if (isset($data['table_id']) && isset($data['items'])) {
    $table_id = $data['table_id'];
    $items = $data['items'];
    
    try {
        // 1. Bu masada zaten açık bir sipariş var mı?
        $stmt = $pdo->prepare("SELECT id FROM orders WHERE table_id = ? AND status = 'active'");
        $stmt->execute([$table_id]);
        $order = $stmt->fetch();
        
        $order_id = 0;
        
        if ($order) {
            // Varsa o siparişi kullan
            $order_id = $order['id'];
            
            // Sipariş güncellendiği için saatini de güncelle (Mutfak sırası için)
            $pdo->prepare("UPDATE orders SET updated_at = ? WHERE id = ?")->execute([$simdi, $order_id]);
        } else {
            // Yoksa YENİ sipariş oluştur ve SAATİ KAYDET
            // waiter_id ekledik (Garson takibi için)
            $waiter_id = isset($_SESSION['staff_id']) ? $_SESSION['staff_id'] : 0;
            
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, table_id, status, created_at, updated_at, kitchen_status, waiter_id) VALUES (?, ?, 'active', ?, ?, 'pending', ?)");
            $stmt->execute([$user_id, $table_id, $simdi, $simdi, $waiter_id]);
            $order_id = $pdo->lastInsertId();
            
            // Masayı dolu yap
            $pdo->prepare("UPDATE restaurant_tables SET status = 1 WHERE id = ?")->execute([$table_id]);
        }
        
        // 2. Ürünleri Ekle
        $total_add = 0;
        foreach ($items as $item) {
            $p_id = $item['id'];
            $qty = $item['qty'];
            
            // Ürün fiyatını ve ismini çek (Güvenlik için veritabanından alıyoruz)
            $stmt_p = $pdo->prepare("SELECT name, price FROM products WHERE id = ?");
            $stmt_p->execute([$p_id]);
            $prod_db = $stmt_p->fetch();
            
            if ($prod_db) {
                $price = $prod_db['price'];
                $name = $prod_db['name'];
                
                $pdo->prepare("INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?, ?, ?, ?, ?)")
                    ->execute([$order_id, $p_id, $name, $qty, $price]);
                
                $total_add += ($price * $qty);
            }
        }
        
        // 3. Toplam Tutarı Güncelle
        $pdo->prepare("UPDATE orders SET total_amount = total_amount + ?, kitchen_status = 'pending' WHERE id = ?")->execute([$total_add, $order_id]);
        
        echo json_encode(['status'=>'success']);
        
    } catch (Exception $e) {
        echo json_encode(['status'=>'error', 'message'=>$e->getMessage()]);
    }
} else {
    echo json_encode(['status'=>'error', 'message'=>'Eksik veri']);
}
?>