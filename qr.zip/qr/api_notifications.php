<?php
session_start();
include 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['count' => 0]);
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$count = 0;

if ($role == 'admin') {
    // Admin ise: Kullanıcılardan gelen okunmamış mesajları say
    $sql = "SELECT COUNT(*) FROM ticket_messages WHERE sender_role = 'user' AND is_read = 0";
    $count = $pdo->query($sql)->fetchColumn();
} else {
    // Kullanıcı ise: Adminden gelen okunmamış mesajları say
    $sql = "SELECT COUNT(*) FROM ticket_messages m 
            JOIN tickets t ON m.ticket_id = t.id 
            WHERE t.user_id = ? AND m.sender_role = 'admin' AND m.is_read = 0";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
    $count = $stmt->fetchColumn();
}

echo json_encode(['count' => $count]);
?>