<?php
// api_waiter.php - Masaların Anlık Durumunu Verir
ob_start();
session_start();
include 'db.php';
ob_end_clean();

error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['role'])) { echo json_encode([]); exit; }

$user_id = $_SESSION['user_id'];
$waiter_id = isset($_SESSION['staff_id']) ? $_SESSION['staff_id'] : 0;
$my_role = $_SESSION['role'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action == 'get_tables') {
    try {
        // Garsonun yetkili olduğu masaları getiren sorgu (waiter.php ile aynı mantık)
        if ($my_role == 'admin' || $my_role == 'restaurant') {
            $sql = "SELECT id, status FROM restaurant_tables WHERE user_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$user_id]);
        } else {
            // Çoklu garson desteği ile (FIND_IN_SET)
            $sql = "SELECT id, status FROM restaurant_tables 
                    WHERE user_id = ? 
                    AND (
                        FIND_IN_SET(?, assigned_waiter_id) 
                        OR assigned_waiter_id IS NULL 
                        OR assigned_waiter_id = '0' 
                        OR assigned_waiter_id = ''
                    )";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$user_id, $waiter_id]);
        }
        
        $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($tables);

    } catch (Exception $e) {
        echo json_encode([]);
    }
}
?>