<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$user_id = $_SESSION['user_id'];

// --- YENİ BİLET OLUŞTURMA ---
if (isset($_POST['create_ticket'])) {
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);
    
    // 1. Bileti oluştur
    $stmt = $pdo->prepare("INSERT INTO tickets (user_id, subject) VALUES (?, ?)");
    $stmt->execute([$user_id, $subject]);
    $ticket_id = $pdo->lastInsertId();
    
    // 2. İlk mesajı kaydet
    $stmt = $pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_role, message) VALUES (?, 'user', ?)");
    $stmt->execute([$ticket_id, $message]);
    
    header("Location: support.php?view=" . $ticket_id); exit;
}

// --- CEVAP YAZMA ---
if (isset($_POST['reply_ticket'])) {
    $t_id = $_POST['ticket_id'];
    $msg = htmlspecialchars($_POST['message']);
    
    // Mesajı kaydet
    $stmt = $pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_role, message) VALUES (?, 'user', ?)");
    $stmt->execute([$t_id, $msg]);
    
    // Bileti güncelle (Tarih yenilensin)
    $pdo->prepare("UPDATE tickets SET updated_at = NOW(), status = 'acik' WHERE id = ?")->execute([$t_id]);
    
    header("Location: support.php?view=" . $t_id); exit;
}

// --- DETAY GÖRÜNTÜLEME (OKUNDU İŞARETLEME) ---
$view_ticket = null;
if (isset($_GET['view'])) {
    $t_id = $_GET['view'];
    
    // Güvenlik: Bu bilet kullanıcının mı?
    $stmt = $pdo->prepare("SELECT * FROM tickets WHERE id = ? AND user_id = ?");
    $stmt->execute([$t_id, $user_id]);
    $view_ticket = $stmt->fetch();
    
    if($view_ticket) {
        // Admin mesajlarını okundu yap
        $pdo->prepare("UPDATE ticket_messages SET is_read = 1 WHERE ticket_id = ? AND sender_role = 'admin'")->execute([$t_id]);
        
        // Mesajları çek
        $msgs = $pdo->prepare("SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC");
        $msgs->execute([$t_id]);
        $messages = $msgs->fetchAll();
    }
}

// Biletleri Listele
$my_tickets = $pdo->prepare("SELECT * FROM tickets WHERE user_id = ? ORDER BY updated_at DESC");
$my_tickets->execute([$user_id]);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Destek Taleplerim</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand">Destek Merkezi</span>
        <a href="panel.php" class="btn btn-outline-light btn-sm">Panele Dön</a>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <button class="btn btn-primary w-100 mb-3" data-bs-toggle="modal" data-bs-target="#newTicketModal">+ Yeni Destek Talebi</button>
            
            <div class="list-group">
                <?php foreach($my_tickets as $tick): ?>
                    <?php 
                        // Okunmamış mesaj var mı kontrol et
                        $unread = $pdo->prepare("SELECT count(*) FROM ticket_messages WHERE ticket_id = ? AND sender_role = 'admin' AND is_read = 0");
                        $unread->execute([$tick['id']]);
                        $count = $unread->fetchColumn();
                        $activeClass = (isset($_GET['view']) && $_GET['view'] == $tick['id']) ? 'active' : '';
                    ?>
                    <a href="support.php?view=<?php echo $tick['id']; ?>" class="list-group-item list-group-item-action <?php echo $activeClass; ?>">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1"><?php echo htmlspecialchars($tick['subject']); ?></h6>
                            <small><?php echo date("d.m H:i", strtotime($tick['updated_at'])); ?></small>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">Durum: 
                                <?php echo ($tick['status']=='acik') ? '<span class="text-success">Açık</span>' : '<span class="text-danger">Kapalı</span>'; ?>
                            </small>
                            <?php if($count > 0): ?>
                                <span class="badge bg-danger rounded-pill"><?php echo $count; ?> Yeni</span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="col-md-8">
            <?php if($view_ticket): ?>
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Konu: <?php echo htmlspecialchars($view_ticket['subject']); ?></h5>
                        <?php if($view_ticket['status'] == 'kapali'): ?>
                            <span class="badge bg-secondary">Bu talep kapatılmıştır.</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body overflow-auto" style="max-height: 500px; background: #f8f9fa;">
                        <?php foreach($messages as $m): ?>
                            <div class="d-flex mb-3 <?php echo ($m['sender_role']=='user') ? 'justify-content-end' : 'justify-content-start'; ?>">
                                <div class="p-3 rounded shadow-sm" style="max-width: 75%; background-color: <?php echo ($m['sender_role']=='user') ? '#dcf8c6' : '#fff'; ?>;">
                                    <small class="d-block text-muted mb-1">
                                        <?php echo ($m['sender_role']=='user') ? 'Siz' : 'Destek Ekibi'; ?> - <?php echo date("H:i", strtotime($m['created_at'])); ?>
                                    </small>
                                    <?php echo nl2br(htmlspecialchars($m['message'])); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if($view_ticket['status'] == 'acik'): ?>
                    <div class="card-footer bg-white">
                        <form method="post">
                            <input type="hidden" name="ticket_id" value="<?php echo $view_ticket['id']; ?>">
                            <div class="input-group">
                                <textarea name="message" class="form-control" rows="2" placeholder="Cevabınızı yazın..." required></textarea>
                                <button type="submit" name="reply_ticket" class="btn btn-primary">Gönder</button>
                            </div>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Görüntülemek için soldan bir talep seçin veya yeni oluşturun.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="modal fade" id="newTicketModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="post" class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Yeni Destek Talebi</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="mb-3"><label>Konu</label><input type="text" name="subject" class="form-control" required></div>
                <div class="mb-3"><label>Mesajınız</label><textarea name="message" class="form-control" rows="4" required></textarea></div>
            </div>
            <div class="modal-footer"><button type="submit" name="create_ticket" class="btn btn-primary">Oluştur</button></div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>