<?php
// kitchen.php - YETKİLENDİRME VE TARGET ID DESTEKLİ
session_start();
include 'db.php';

// 1. GİRİŞ KONTROLÜ
if (!isset($_SESSION['role'])) { header("Location: login.php"); exit; }

// 2. YETKİ KONTROLÜ (Mutfak, Restoran Sahibi ve Admin girebilir)
$allowed_roles = ['kitchen', 'restaurant', 'admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    die("Bu sayfaya erişim yetkiniz yok.");
}

// 3. HEDEF KULLANICIYI BELİRLE
$view_user_id = $_SESSION['user_id']; 

if (($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'restaurant') && isset($_GET['target_id'])) {
    $view_user_id = $_GET['target_id'];
}

$api_params = "?target_id=" . $view_user_id; 
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Mutfak Ekranı</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #212529; color: white; }
        .order-card { background-color: #343a40; border: 2px solid #495057; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 4px 8px rgba(0,0,0,0.3); transition: transform 0.2s; }
        .order-card:hover { transform: translateY(-5px); border-color: #ffc107; }
        .card-header { background-color: #ffc107; color: #212529; font-weight: bold; font-size: 1.2rem; display: flex; justify-content: space-between; align-items: center; border-radius: 8px 8px 0 0; }
        .order-time { font-size: 0.9rem; background: #212529; color: #ffc107; padding: 2px 8px; border-radius: 5px; }
        .product-list { list-style: none; padding: 0; margin: 0; }
        .product-item { padding: 10px; border-bottom: 1px solid #495057; font-size: 1.1rem; display: flex; justify-content: space-between; }
        .product-item:last-child { border-bottom: none; }
        .qty-badge { background-color: #dc3545; color: white; padding: 2px 10px; border-radius: 50px; font-weight: bold; }
        .btn-ready { width: 100%; border-radius: 0 0 8px 8px; font-weight: bold; padding: 15px; font-size: 1.2rem; }
        .masonry-container { column-count: 1; column-gap: 20px; }
        @media (min-width: 768px) { .masonry-container { column-count: 2; } }
        @media (min-width: 1200px) { .masonry-container { column-count: 3; } }
        .card-break { display: inline-block; width: 100%; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark border-bottom border-secondary mb-4">
    <div class="container-fluid">
        <span class="navbar-brand mb-0 h1"><i class="bi bi-fire text-warning"></i> Mutfak Ekranı</span>
        <div class="text-end text-white"><span id="clock" class="fw-bold fs-4">00:00</span></div>
    </div>
</nav>

<div class="container-fluid">
    <div id="orders-container" class="masonry-container">
        <div class="text-center text-muted mt-5"><div class="spinner-border text-warning" role="status"></div><br>Siparişler Yükleniyor...</div>
    </div>
</div>

<audio id="alertSound" src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3"></audio>

<script>
    const apiSuffix = "<?php echo $api_params; ?>";
    let knownOrders = []; 

    function updateClock() { document.getElementById('clock').innerText = new Date().toLocaleTimeString('tr-TR', {hour: '2-digit', minute:'2-digit'}); }
    setInterval(updateClock, 1000); updateClock();

    function fetchOrders() {
        fetch('api_kitchen.php?action=get_pending' + "&" + apiSuffix.replace('?', ''))
            .then(response => response.json())
            .then(data => {
                const container = document.getElementById('orders-container');
                let html = '';
                
                let currentIds = data.map(o => o.id);
                let isNew = currentIds.some(id => !knownOrders.includes(id));
                if (isNew && knownOrders.length > 0) { document.getElementById('alertSound').play().catch(e=>{}); }
                knownOrders = currentIds;

                if (data.length === 0) { container.innerHTML = '<div class="text-center text-secondary mt-5 card-break w-100"><h4>Aktif Sipariş Yok</h4><p>Şu an bekleyen sipariş bulunmuyor.</p></div>'; return; }

                data.forEach(order => {
                    let itemsHtml = '';
                    order.items.forEach(item => { itemsHtml += `<li class="product-item"><span>${item.product_name}</span> <span class="qty-badge">x${item.quantity}</span></li>`; });
                    html += `<div class="card-break"><div class="order-card"><div class="card-header"><span>${order.table_name}</span><span class="order-time"><i class="bi bi-clock"></i> ${order.formatted_time}</span></div><ul class="product-list">${itemsHtml}</ul><button onclick="setReady(${order.id})" class="btn btn-success btn-ready">HAZIR <i class="bi bi-check-lg"></i></button></div></div>`;
                });
                container.innerHTML = html;
            }).catch(err => console.error(err));
    }

    function setReady(orderId) {
        if(!confirm('Sipariş hazırlandı mı?')) return;
        let formData = new FormData(); formData.append('order_id', orderId);
        fetch('api_kitchen.php?action=set_ready', { method: 'POST', body: formData }).then(r => r.json()).then(d => { fetchOrders(); });
    }

    setInterval(fetchOrders, 5000);
    fetchOrders();
</script>
</body>
</html>