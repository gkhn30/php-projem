<?php
session_start();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Menü Sistemi - Dijital Menünü Oluştur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .feature-icon {
            font-size: 3rem;
            color: #764ba2;
            margin-bottom: 1rem;
        }
        .card {
            border: none;
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="index.php">
                <i class="bi bi-qr-code-scan"></i> QR Menü
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <span class="nav-link text-dark">Hoşgeldin, <b><?php echo $_SESSION['store_name']; ?></b></span>
                        </li>
                        <li class="nav-item ms-2">
                            <?php if($_SESSION['role'] == 'admin'): ?>
                                <a href="admin.php" class="btn btn-primary">Admin Paneli</a>
                            <?php else: ?>
                                <a href="panel.php" class="btn btn-primary">Yönetim Paneli</a>
                            <?php endif; ?>
                        </li>
                        <li class="nav-item ms-2">
                            <a href="logout.php" class="btn btn-outline-danger">Çıkış</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Giriş Yap</a>
                        </li>
                        <li class="nav-item ms-2">
                            <a href="register.php" class="btn btn-success">Ücretsiz Kayıt Ol</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <header class="hero-section">
        <div class="container">
            <h1 class="display-4 fw-bold mb-3">Restoranınız İçin Temassız QR Menü</h1>
            <p class="lead mb-4">Dakikalar içinde menünü oluştur, QR kodunu al ve müşterilerine sun. <br> Mobil uyumlu, hızlı ve yönetim panelli.</p>
            
            <?php if(!isset($_SESSION['user_id'])): ?>
                <a href="register.php" class="btn btn-light btn-lg px-5 fw-bold text-primary">Hemen Başla</a>
            <?php else: ?>
                <a href="panel.php" class="btn btn-light btn-lg px-5 fw-bold text-primary">Menünü Düzenle</a>
            <?php endif; ?>
        </div>
    </header>

    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Neler Yapabilirsiniz?</h2>
                <p class="text-muted">Sistemin size sunduğu temel özellikler</p>
            </div>
            
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-phone"></i>
                        </div>
                        <h4 class="card-title">Mobil Uyumlu Menü</h4>
                        <p class="card-text">Müşterileriniz uygulama indirmeden, sadece kamerayı açarak menünüze anında ulaşır.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card h-100 shadow-sm p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-pencil-square"></i>
                        </div>
                        <h4 class="card-title">Kolay Yönetim</h4>
                        <p class="card-text">Fiyatları güncelleyin, yeni ürün ekleyin veya tükenen ürünleri tek tıkla pasife alın.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card h-100 shadow-sm p-4 text-center">
                        <div class="feature-icon">
                            <i class="bi bi-qr-code"></i>
                        </div>
                        <h4 class="card-title">Otomatik QR Kod</h4>
                        <p class="card-text">Profilinizi oluşturduğunuz anda size özel QR kodunuz sistem tarafından otomatik üretilir.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white py-4 mt-auto">
        <div class="container text-center">
            <p class="mb-0">&copy; <?php echo date("Y"); ?> QR Menü Sistemi. Tüm hakları saklıdır.</p>
            <small class="text-white-50">PHP & Bootstrap ile geliştirildi.</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>