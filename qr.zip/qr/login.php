<?php
session_start();
include 'db.php';

// Zaten giriş yapmışsa yönlendir
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') { header("Location: admin.php"); }
    elseif ($_SESSION['role'] == 'restaurant') { header("Location: panel.php"); }
    elseif ($_SESSION['role'] == 'waiter') { header("Location: waiter.php"); }
    elseif ($_SESSION['role'] == 'cashier') { header("Location: cashier.php"); }
    elseif ($_SESSION['role'] == 'kitchen') { header("Location: kitchen.php"); } // <-- BU EKSİKTİ
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // 1. Önce Admin/Restoran Sahibi Tablosuna Bak (users)
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['is_active'] == 0) {
            $error = "Hesabınız pasif durumdadır.";
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['store_name'] = $user['store_name'];
            $_SESSION['role'] = $user['role']; // 'admin' veya 'restaurant'
            
            if($user['role'] == 'admin') header("Location: admin.php");
            else header("Location: panel.php");
            exit;
        }
    } else {
        // 2. Admin Değilse Personel Tablosuna Bak (staff)
        $stmt2 = $pdo->prepare("SELECT * FROM staff WHERE username = ?");
        $stmt2->execute([$username]);
        $staff = $stmt2->fetch();

        if ($staff && $password == $staff['password']) {
            $_SESSION['staff_id'] = $staff['id'];
            $_SESSION['user_id'] = $staff['user_id']; // Hangi restoranın personeli
            $_SESSION['role'] = $staff['role']; // 'waiter', 'cashier' veya 'kitchen'
            $_SESSION['name'] = $staff['name'];

            // ROL KONTROLÜ VE YÖNLENDİRME
            if ($staff['role'] == 'waiter') {
                header("Location: waiter.php");
            } elseif ($staff['role'] == 'cashier') {
                header("Location: cashier.php");
            } elseif ($staff['role'] == 'kitchen') { 
                header("Location: kitchen.php"); // <-- BURASI EKLENDİ
            }
            exit;
        } else {
            $error = "Kullanıcı adı veya şifre hatalı!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Giriş Yap</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { width: 100%; max-width: 400px; border-radius: 15px; border: none; }
    </style>
</head>
<body>
    <div class="card login-card shadow p-4">
        <div class="text-center mb-4">
            <h3 class="fw-bold text-primary">Sistem Girişi</h3>
            <p class="text-muted small">Restoran Yönetim Paneli</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger text-center py-2"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label fw-bold">Kullanıcı Adı</label>
                <input type="text" name="username" class="form-control form-control-lg" required>
            </div>
            <div class="mb-4">
                <label class="form-label fw-bold">Şifre</label>
                <input type="password" name="password" class="form-control form-control-lg" required>
            </div>
            <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold">Giriş Yap</button>
        </form>
        
        <div class="text-center mt-4 text-muted small">
            &copy; <?php echo date('Y'); ?> QR Menü Sistemi
        </div>
    </div>
</body>
</html>